import { useState, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import { FileText, List, HelpCircle } from "lucide-react";
import { getHistory, saveToHistory } from "../components/History";
import { marked } from "marked"; // ✅ Markdown parser

const ai = new GoogleGenAI({
  apiKey: import.meta.env.VITE_GEMINI_API_KEY,
});

export default function Summary() {
  const [prompt, setPrompt] = useState("");
  const [summaryType, setSummaryType] = useState("summary");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = getHistory();
    console.log("History loaded:", saved);
  }, []);

  const askGemini = async () => {
    setLoading(true);
    setResponse("");

    let formattedPrompt = "";
    switch (summaryType) {
      case "questions":
        formattedPrompt = `Generate questions based on the following text:\n${prompt}`;
        break;
      case "bullets":
        formattedPrompt = `Summarize the following text into concise bullet points:\n${prompt}`;
        break;
      case "summary":
      default:
        formattedPrompt = `Provide a concise summary of the following text:\n${prompt}`;
        break;
    }

    try {
      const result = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: formattedPrompt,
      });

      const answer = result.text ?? "";
      setResponse(answer);

      saveToHistory({
        prompt,
        response: answer,
        type: summaryType,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error(err);
      setResponse("Error fetching response.");
    }

    setLoading(false);
  };

  const summaryOptions = [
    { key: "summary", label: "Summary", icon: FileText },
    { key: "bullets", label: "Bullet", icon: List },
    { key: "questions", label: "Questions", icon: HelpCircle },
  ];

  return (
    <div className="max-w-2xl mx-auto p-6 font-sans">
      <h1 className="text-2xl font-bold mb-4 text-center">Ask StudyFlowAI ✨</h1>

      <div className="flex justify-center gap-4 mb-4">
        {summaryOptions.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setSummaryType(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-200
              ${summaryType === key
                ? "bg-blue-600 text-white border-blue-600 shadow"
                : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100"
              }`}
          >
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      <textarea
        rows={5}
        className="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Paste your text or ask a question..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />

      <button
        onClick={askGemini}
        disabled={loading}
        className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 w-full"
      >
        {loading ? "Thinking..." : "Ask"}
      </button>

      {response && (
        <div className="mt-6 bg-gray-100 p-4 rounded-md prose prose-sm max-w-none">
          <strong className="block mb-2 text-gray-700">Gemini says:</strong>
          <div
            dangerouslySetInnerHTML={{ __html: marked(response) }}
          />
        </div>
      )}
    </div>
  );
}