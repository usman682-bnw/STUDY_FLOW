
import Summarizer from "./pages/Summarizer"

export default function App() {
  return (
    <>
    <Summarizer />
    
    </>

  )
}